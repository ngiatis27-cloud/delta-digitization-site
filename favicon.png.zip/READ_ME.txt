UPDATED WEBSITE VERSION

Changes made:
- Kept everything the same
- Changed the header logo to the same image used for the favicon / Facebook profile picture

Upload these files to your GitHub root folder:
- index.html
- favicon.png
- favicon.ico
- vintage_family_memories_and_keepsakes.png

Keep your existing JPGs there too:
- before_dance.jpg
- after_dance.jpg
- Yiayia_ORIG.jpg
- Yiayia_Fix.jpg
- before_kitchen.jpg
- after_kitchen.jpg
