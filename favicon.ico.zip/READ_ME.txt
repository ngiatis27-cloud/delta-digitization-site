UPDATED VERSION WITH MORE REALISTIC HOMEPAGE IMAGE

Files to keep in your main GitHub folder:
- index.html
- vintage_family_memories_and_keepsakes.png
- before_dance.jpg
- after_dance.jpg
- Yiayia_ORIG.jpg
- Yiayia_Fix.jpg
- before_kitchen.jpg
- after_kitchen.jpg

This version replaces the bland homepage graphic with the more realistic image.
